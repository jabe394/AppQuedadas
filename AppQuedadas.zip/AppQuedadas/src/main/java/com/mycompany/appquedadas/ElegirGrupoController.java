package com.mycompany.appquedadas;
import com.mycompany.appquedadas.model.BaseDeDatos;
import com.mycompany.appquedadas.model.InfoApp;
import com.mycompany.appquedadas.model.Conexion;
import com.mycompany.appquedadas.model.Tabla;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;

public class ElegirGrupoController {
    InfoApp info = new InfoApp();
    @FXML VBox listaGrupos_VBox;
    @FXML ListView ListView_ListaGrupos;
    Conexion conexionClass;
    ObservableList<String> listaGrupos = FXCollections.observableArrayList();
    Tabla tablaUsuarios;
    Tabla tablaGrupos;
    ArrayList<ArrayList<String>> listaInfoGruposUsuarioAsignado;
    
    @FXML public void Button_Home_OnAction() throws IOException{
        App.setRoot(info.getNombreFxmlController(1));
    }
    
    @FXML public void Button_CrearGrupo_OnAction() throws IOException{
        App.setRoot(info.getNombreFxmlController(5));
    }
    
    @FXML public void MenuItem_Eliminar_OnAction() throws SQLException {
        Object valorSeleccionado = ListView_ListaGrupos.getSelectionModel().getSelectedItem();
        if (valorSeleccionado != null) {
            String nombreTabla = tablaGrupos.getNombre();
            String columna = tablaGrupos.getColumnas()[0];
            String identificador = (String)valorSeleccionado;
            conexionClass.deleteDatoTabla(nombreTabla, columna, identificador);
            listaGrupos.remove(identificador);
        }
    }
    
    @FXML public void ListView_ListaGrupos_OnMouseClicked(){
        
        int indexSeleccionado = ListView_ListaGrupos.getSelectionModel().getSelectedIndex();
        if (indexSeleccionado != -1) { 
            System.out.println("Redirigiendo Interfaz del Grupo: " + listaInfoGruposUsuarioAsignado.get(indexSeleccionado).get(1) + " Con ID: " + listaInfoGruposUsuarioAsignado.get(indexSeleccionado).get(0));
        }
    }
    
    
    
    public void actualizarListaGrupos() throws SQLException{
        listaGrupos.clear();
        String nombreTabla = tablaGrupos.getNombre();
        String identificadorColumnaGrupo = tablaGrupos.getColumnas()[0];
        String nombreColumnaGrupo = tablaGrupos.getColumnas()[1];
        String nombreColumnaLista = tablaGrupos.getColumnas()[2];
        String gmailUsuarioActivo = InfoApp.getID_UsuarioActivo();
        listaInfoGruposUsuarioAsignado = conexionClass.getFilasValorEnLista(nombreTabla, tablaGrupos.getColumnas(),  nombreColumnaLista, gmailUsuarioActivo);
        for (ArrayList infoGrupo : listaInfoGruposUsuarioAsignado){
            listaGrupos.add((String)infoGrupo.get(1));
        }
        
    }
    
    public void initialize() throws SQLException, ClassNotFoundException{
        conexionClass = BaseDeDatos.getConexionBaseDatos();
        ListView_ListaGrupos.setItems(listaGrupos);
        tablaUsuarios = info.getBaseDeDatos().getTabla(1);
        tablaGrupos = info.getBaseDeDatos().getTabla(2);
        
        actualizarListaGrupos();
    }
}
