/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appquedadas;

import com.mycompany.appquedadas.model.BaseDeDatos;
import com.mycompany.appquedadas.model.Conexion;
import com.mycompany.appquedadas.model.InfoApp;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jbert
 */
public class ElegirVotaciónController {
    Conexion conexionClass;
    InfoApp info;
    BaseDeDatos infoBaseDeDatos;
    
    public void initialize() throws SQLException, ClassNotFoundException{
        info = new InfoApp();
        infoBaseDeDatos = info.getBaseDeDatos();
        conexionClass = BaseDeDatos.getConexionBaseDatos();
    }
}
