package com.mycompany.appquedadas;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import com.mycompany.appquedadas.model.Conexion;
import com.mycompany.appquedadas.model.InfoApp;
import com.mycompany.appquedadas.model.BaseDeDatos;
import com.mycompany.appquedadas.model.Tabla;
import com.mycompany.appquedadas.model.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javafx.scene.text.Text;

public class RegistraseController {
    @FXML TextField TextField_Gmail;
    @FXML Text Text_Error;
    @FXML TextField TextField_Contraseña;
    private Conexion conexionClass;
    private InfoApp info = new InfoApp();
    private BaseDeDatos baseDeDatos;
    private Tabla tablaUsuarios;
    
    public boolean usuarioExiste(Usuario usuario) throws SQLException {
        
        String nombreTabla = tablaUsuarios.getNombre();
        String nombreColumnaGmail = tablaUsuarios.getColumnas()[0];
        ResultSet res = conexionClass.getFilaTabla(nombreTabla, nombreColumnaGmail, usuario.getGmail());
        return res.next();
    }

    public void crearUsuario(Usuario usuario) throws SQLException, IOException{
        String nombreTablaUsuarios = tablaUsuarios.getNombre();
        ArrayList<Object> infoUsuario = new ArrayList<>();
        infoUsuario.add(usuario.getGmail());
        infoUsuario.add(usuario.getContraseña());
        conexionClass.addDatoTabla(nombreTablaUsuarios, infoUsuario);

    }

    @FXML
    public void Button_IniciarSesion_OnAction() throws SQLException, IOException{ 
        String nombreColumnaContraseña = "Contraseña";
        Map<String,String> tiposErrores = Map.of(
                "Formato", "Error: El Gmail debe terminar en: " + convertirArrayAString(getListaTiposFormatosGmail())
                , "Contraseña", "La contraseña con el Usuario no Coincide");
        String gmail = TextField_Gmail.getText().trim();
        String contraseñaIntroducida = TextField_Contraseña.getText().trim();
        Usuario usuario = new Usuario(gmail, contraseñaIntroducida, nombreColumnaContraseña);
        
        if (!formatoGmailValido(gmail)){
            String error = tiposErrores.get("Formato");
            Text_Error.setText(error);
            return;
        }
        
        
        if (!usuarioExiste(usuario)){
            System.out.println("Se ha creado un nuevo perfil de Usuario!");
            crearUsuario(usuario);
            App.setRoot(info.getNombreFxmlController(3));
        }
        
        if (!contraseñaCorrecta(usuario)){
            String error = tiposErrores.get("Contraseña");
            Text_Error.setText(error);
            return;
        }
        
        System.out.println("El usuario ya existe!");
         // Desactiva Esto para que pueda el mismo usuario solo añadir a usuarios que no fueron creados por el
        InfoApp.setID_UsuarioActivo(gmail);
        App.setRoot(info.getNombreFxmlController(4));

        
    }
    
    private static final String[] listaTiposFormatosGmail = {"@gmail.com", "@googlemail.com"};
    public boolean formatoGmailValido(String gmail){
        for (String formato : listaTiposFormatosGmail){
            if (gmail.contains(formato)){
                return true;
            }
        }
        return false;
    }
    
    public String convertirArrayAString(String[] array){
        return Arrays.toString(array);
    }

    public static String[] getListaTiposFormatosGmail() {
        return listaTiposFormatosGmail;
    }
    
    
    
    public boolean contraseñaCorrecta(Usuario usuario) throws SQLException{
        String nombreTablaUsuarios = tablaUsuarios.getNombre();
        String nombreColumnaGmail = tablaUsuarios.getColumnas()[0];
        String nombreColumnaContraseña = tablaUsuarios.getColumnas()[1];
        ResultSet res = conexionClass.getFilaTabla(nombreTablaUsuarios, nombreColumnaGmail, usuario.getGmail());
        if (res.next()){
            return usuario.getContraseña().equals(res.getString(nombreColumnaContraseña));
        }
        return false; // Afegir un metode de comparació entre contraseña del usuari existent amb la constraseña introduida
    }
    
    public void initialize() throws SQLException, ClassNotFoundException{
        this.conexionClass = BaseDeDatos.getConexionBaseDatos();
        this.baseDeDatos = info.getBaseDeDatos();
        this.tablaUsuarios = baseDeDatos.getTabla(1);
    }
}