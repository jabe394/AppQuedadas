/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appquedadas.model;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
/**
 *
 * @author alumne
 */
public class Conexion {
    BaseDeDatos baseDeDatos; 
    Connection conexion;
    AppInfo info = new AppInfo();
    
    public Conexion(BaseDeDatos baseDeDatos) throws SQLException, ClassNotFoundException {
        this.baseDeDatos = baseDeDatos;
        this.conexion = getConnexionBaseDatos();
    }
    
    private Connection getConnexionBaseDatos() throws SQLException, ClassNotFoundException{
        String rutaBasedeDatos = "jdbc:mysql://localhost:" + baseDeDatos.getPuertoBaseDatos() + "/" + baseDeDatos.getNombreBaseDeDatosPorDefecto();
        Connection conDef = DriverManager.getConnection(rutaBasedeDatos, this.baseDeDatos.getNombreUsuario(), this.baseDeDatos.getContraseña());
        if (conDef != null){
            String sql = "CREATE DATABASE IF NOT EXISTS " + baseDeDatos.getNombreBaseDeDatos();
            Statement stmt = conDef.createStatement();
            stmt.executeUpdate(sql);
            stmt.close();
            System.out.println("Base de datos creada exitosamente (si no existía).");
            
            conDef.setCatalog(baseDeDatos.getNombreBaseDeDatos());
            
            for (Tabla tabla : baseDeDatos.getListaTablas()){
                sql = setConsultaCrearTabla(tabla);
                System.out.print("Consulta Inserción Tabla: " + sql);
                stmt = conDef.createStatement();
                stmt.executeUpdate(sql);
                System.out.println("Tabla creada exitosamente (si no existía).");
            }
            
           
            stmt = conDef.createStatement();
            stmt.executeUpdate(sql);
            System.out.println("Tabla creada exitosamente (si no existía).");
            return conDef;      
        }
        else{
            System.out.println("Conexion no Exitosa");
        }
        return null;
    }
    
    public ResultSet getResultadoConsulta(String consulta) throws SQLException{
        Statement stm = this.conexion.createStatement();
        ResultSet res = stm.executeQuery(consulta);
        return res;
    }
    
    public String setConsultaCrearTabla(Tabla tabla){
        String sql = "CREATE TABLE IF NOT EXISTS " + tabla.getNombre() + "(";
        for (int i = 0; i < tabla.getColumnas().length; i++) {
            sql += tabla.getColumnas()[i] + " VARCHAR(100)";
            if (i < tabla.getColumnas().length - 1) {
                sql += ", ";
            }
        }
        sql += ");";
        return sql;
    }

    public void setDatoTabla(String nombreTabla, ArrayList<Object> valores) throws SQLException {
        String sql = "INSERT INTO " + nombreTabla + " VALUES(";

        for (int i = 0; i < valores.size(); i++) {
            sql += "?, ";
        }
        sql = sql.substring(0, sql.length() - 2); // Eliminar la última coma y espacio
        sql += ")";

        PreparedStatement ps = this.conexion.prepareStatement(sql);

        for (int i = 0; i < valores.size(); i++) {
            ps.setObject(i + 1, valores.get(i));
        }

        ps.executeUpdate();
    }
    
    public ResultSet getDatosTabla(String nombreTabla) throws SQLException {
        String sql = "SELECT * FROM " + nombreTabla;
        Statement stmt = this.conexion.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        return rs;
    }
    
    public ResultSet getFilaTabla(String nombreTabla, String columna, String identificador) throws SQLException {
        String sql = "SELECT * FROM " + nombreTabla + " WHERE " + columna + " = " + "'" + identificador + "'";
        Statement stmt = this.conexion.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        return rs;
    }
}
